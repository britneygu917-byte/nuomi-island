import fs from "node:fs";
import path from "node:path";

const dir = "dist-single";
const html = fs.readFileSync(path.join(dir, "index.html"), "utf8");
const css = fs.readFileSync(path.join(dir, "app.css"), "utf8");
const js = fs.readFileSync(path.join(dir, "app.js"), "utf8");

const safeJs = js.replace(/<\/script/gi, "<\\/script");

const out = html
  .replace(/<link[^>]*rel="stylesheet"[^>]*>/g, `<style>${css}</style>`)
  .replace(/<link[^>]*rel="icon"[^>]*>/g, "")
  .replace(
    /<script[^>]*src="[^"]*app\.js"[^>]*><\/script>/g,
    `<script type="module">${safeJs}</script>`,
  );

fs.writeFileSync("nuomi-island-standalone.html", out, "utf8");
console.log("merged bytes:", out.length);
console.log("leftover external refs:", (out.match(/src="\.\/|href="\.\//g) || []).length);
