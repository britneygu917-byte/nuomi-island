import { defineConfig } from "vite";
export default defineConfig({
  base: "./",
  build: {
    outDir: "dist-single",
    cssCodeSplit: false,
    assetsInlineLimit: 100000000,
    rollupOptions: {
      output: {
        inlineDynamicImports: true,
        entryFileNames: "app.js",
        assetFileNames: "app.[ext]",
      },
    },
  },
});
